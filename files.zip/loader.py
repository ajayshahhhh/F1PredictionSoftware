"""
OpenF1 telemetry loader.
Fetches car data (speed, throttle, brake) per lap per driver.
Falls back to mock data if API unavailable.
"""

import numpy as np
import json
import urllib.request
import urllib.parse
from pathlib import Path
from data.drivers import DRIVERS

CACHE_DIR = Path(__file__).parent.parent / "cache"
CACHE_DIR.mkdir(exist_ok=True)

MAX_LAPS = 8  # fastest laps per driver to fetch

CIRCUIT_CORNERS = {
    "Australia": {
        "corners": ["T1","T2","T3","T4","T5","T6","T7","T8","T9","T10","T11","T12","T13","T14","T15","T16"],
        "country": "Australia",
    },
    "China": {
        "corners": ["T1","T2","T3","T4","T5","T6","T7","T8","T9","T10","T11","T12","T13","T14","T15","T16"],
        "country": "China",
    },
    "Bahrain": {
        "corners": ["T1","T2","T3","T4","T5","T6","T7","T8","T9","T10","T11","T12","T13","T14","T15"],
        "country": "Bahrain",
    },
    "Japan": {
        "corners": ["T1","T2","T3","T4","T5","T6","T7","T8","T9","T10","T11","T12","T13","T14","T15","T16","T17","T18"],
        "country": "Japan",
    },
}


def _get(endpoint, params):
    url = "https://api.openf1.org/v1/" + endpoint + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def _session_key(year, circuit, stype="R"):
    name_map = {"R": "Race", "Q": "Qualifying", "FP1": "Practice 1"}
    sname = name_map.get(stype, "Race")
    country = CIRCUIT_CORNERS.get(circuit, {}).get("country", circuit)
    res = _get("sessions", {"year": year, "country_name": country, "session_name": sname})
    return res[0]["session_key"] if res else None


def load_session(year: int, circuit: str, session_type: str = "R") -> dict:
    key = f"{year}_{circuit}_{session_type}.json"
    path = CACHE_DIR / key
    if path.exists():
        with open(path) as f:
            return json.load(f)
    try:
        data = _load_openf1(year, circuit, session_type)
    except Exception as e:
        print(f"[loader] OpenF1 failed ({e}), using mock")
        data = _load_mock(circuit)
    with open(path, "w") as f:
        json.dump(data, f)
    return data


def _load_openf1(year, circuit, session_type):
    sk = _session_key(year, circuit, session_type)
    if not sk:
        raise ValueError(f"No session found: {year} {circuit}")

    raw_drivers = _get("drivers", {"session_key": sk})
    acronym_to_num = {d["name_acronym"]: d["driver_number"] for d in raw_drivers if "name_acronym" in d}

    corners = CIRCUIT_CORNERS.get(circuit, CIRCUIT_CORNERS["Australia"])["corners"]
    drivers_out = {}

    for code in DRIVERS:
        num = acronym_to_num.get(code)
        if not num:
            drivers_out[code] = _mock_driver(code, circuit)
            continue
        try:
            laps_raw = _get("laps", {"session_key": sk, "driver_number": num})
            valid = sorted([l for l in laps_raw if l.get("lap_duration", 0) > 0],
                           key=lambda l: l["lap_duration"])[:MAX_LAPS]
            if not valid:
                raise ValueError("no laps")

            laps_out = []
            for lap in valid:
                tel = _get("car_data", {"session_key": sk, "driver_number": num,
                                        "lap_number": lap["lap_number"]})
                if not tel:
                    continue
                speeds    = np.array([t.get("speed", 0)            for t in tel], dtype=float)
                throttles = np.array([t.get("throttle", 0)         for t in tel], dtype=float) / 100
                brakes    = np.array([float(t.get("brake", False)) for t in tel], dtype=float)
                segs = np.array_split(np.arange(len(tel)), len(corners))
                corner_data = []
                for cn, idx in zip(corners, segs):
                    if not len(idx):
                        continue
                    corner_data.append({
                        "corner": cn,
                        "speed":    round(float(speeds[idx].mean()), 2),
                        "throttle": round(float(throttles[idx].mean()), 4),
                        "brake":    round(float(brakes[idx].mean()), 4),
                    })
                laps_out.append({
                    "lap":     lap["lap_number"],
                    "laptime": round(float(lap["lap_duration"]), 3),
                    "corners": corner_data,
                })

            if not laps_out:
                raise ValueError("no usable laps")

            drivers_out[code] = {**DRIVERS[code], "driver": code, "circuit": circuit, "laps": laps_out}
            print(f"[loader] {code}: {len(laps_out)} laps")
        except Exception as e:
            print(f"[loader] {code} fallback ({e})")
            drivers_out[code] = _mock_driver(code, circuit)

    return {"circuit": circuit, "year": year, "drivers": drivers_out,
            "corners": corners}


def _load_mock(circuit):
    corners = CIRCUIT_CORNERS.get(circuit, CIRCUIT_CORNERS["Australia"])["corners"]
    return {
        "circuit": circuit, "year": 0,
        "corners": corners,
        "drivers": {code: _mock_driver(code, circuit) for code in DRIVERS}
    }


def _mock_driver(code, circuit):
    corners = CIRCUIT_CORNERS.get(circuit, CIRCUIT_CORNERS["Australia"])["corners"]
    pts = DRIVERS[code]["points"]
    skill = np.clip(pts / 350.0, 0, 0.12)
    rng = np.random.default_rng(abs(hash(code + circuit)) % (2**31))

    laps = []
    for i in range(MAX_LAPS):
        corner_data = []
        for c_idx, cn in enumerate(corners):
            base_spd = 185 + 55 * np.sin(c_idx * 0.42)
            base_thr = 0.62 + 0.22 * np.cos(c_idx * 0.5)
            base_brk = max(0, 0.28 - 0.14 * np.cos(c_idx * 0.5))
            corner_data.append({
                "corner":   cn,
                "speed":    round(float(base_spd * (1 + skill) + rng.normal(0, 5)), 2),
                "throttle": round(float(np.clip(base_thr * (1 + skill*0.5) + rng.normal(0, 0.04), 0, 1)), 4),
                "brake":    round(float(np.clip(base_brk * (1 - skill*0.3) + rng.normal(0, 0.03), 0, 1)), 4),
            })
        lt = sum((1.9 - skill*0.4 + rng.normal(0, 0.09)) for _ in corners) * 4.8 + rng.normal(0, 0.4)
        laps.append({"lap": i+1, "laptime": round(float(lt), 3), "corners": corner_data})

    return {**DRIVERS[code], "driver": code, "circuit": circuit, "laps": laps}
