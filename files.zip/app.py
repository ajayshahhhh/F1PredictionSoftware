from flask import Flask, render_template, jsonify, request
from models.pipeline import run_pipeline

app = Flask(__name__)
_cache = {}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/analyze")
def analyze():
    year    = int(request.args.get("year", 2026))
    circuit = request.args.get("circuit", "Australia")
    key = f"{year}_{circuit}"
    if key not in _cache:
        _cache[key] = run_pipeline(year, circuit)
    return jsonify(_cache[key])

if __name__ == "__main__":
    print("🏎  F1 Probability Intelligence System v2")
    print("   http://localhost:5001")
    app.run(debug=True, port=5001)
